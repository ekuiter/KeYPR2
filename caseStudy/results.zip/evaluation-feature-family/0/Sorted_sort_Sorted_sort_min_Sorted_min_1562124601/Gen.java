class Gen {
/*@ model boolean Sorted_sort_min_requires(int[] A, int start) { return A.length > 0 && 0 <= start < A.length; }
  @ model boolean Sorted_sort_min_ensures(int[] A, int start, int res) { return start <= res && res < A.length && (\forall int i; start <= i < A.length; A[res] <= A[i]); }
  @ model \locset Sorted_sort_min_assignable(int[] A, int start) { return \set_minus(\nothing, \everything); } */
/*@ requires Sorted_sort_min_requires(A, start);
  @ ensures Sorted_sort_min_ensures(A, start, \result);
  @ assignable Sorted_sort_min_assignable(A, start); */
int min(int[] A, int start);

/*@ requires A.length > 0;
  @ ensures (\forall int i; 0 <= i < A.length - 1; A[i] <= A[i + 1]) && (\forall int i; 0 <= i < \old(A).length; (\exists int j; 0 <= j < A.length; A[j] == \old(A)[i])) && (\forall int i; 0 <= i < A.length; (\exists int j; 0 <= j < \old(A).length; A[i] == \old(A)[j]));
  @ assignable A[*]; */
void main(int[] A) {
    // CALLS int min(int[] A, int start)
    int pos = 0, tmp, i = 0;
    /*@ loop_invariant A.length > 0 && 0 <= pos < A.length && 0 <= i < A.length &&
		  @   (\forall int j; 0 <= j < pos - 1; A[j] <= A[j + 1]) &&
		  @   (pos > 0 ==> (\forall int j; pos <= j < A.length; A[pos - 1] <= A[j]));
		  @ decreases A.length - pos;
		  @ assignable pos, A[*], i, tmp; */
    while (pos < A.length - 1) {
        i = min(A, pos);
        tmp = A[i];
        A[i] = A[pos];
        A[pos] = tmp;
        pos++;
    }
}
}