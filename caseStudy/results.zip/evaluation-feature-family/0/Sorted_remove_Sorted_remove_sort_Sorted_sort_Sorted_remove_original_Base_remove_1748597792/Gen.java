class Gen {
/*@ model boolean Sorted_remove_sort_requires(int[] A) { return A.length > 0; }
  @ model boolean Sorted_remove_sort_ensures(int[] A) { return (\forall int i; 0 <= i < A.length - 1; A[i] <= A[i + 1]) && (\forall int i; 0 <= i < \old(A).length; (\exists int j; 0 <= j < A.length; A[j] == \old(A)[i])) && (\forall int i; 0 <= i < A.length; (\exists int j; 0 <= j < \old(A).length; A[i] == \old(A)[j])); }
  @ model \locset Sorted_remove_sort_assignable(int[] A) { return A[*]; } */
/*@ requires Sorted_remove_sort_requires(A);
  @ ensures Sorted_remove_sort_ensures(A);
  @ assignable Sorted_remove_sort_assignable(A); */
void sort(int[] A);

/*@ model boolean Sorted_remove_original_requires(int[] A, int x) { return A.length > 0; }
  @ model boolean Sorted_remove_original_ensures(int[] A, int x) { return (\forall int i; 0 <= i < A.length; A[i] != x || A[i] == -1); }
  @ model \locset Sorted_remove_original_assignable(int[] A, int x) { return A[*]; } */
/*@ requires Sorted_remove_original_requires(A, x);
  @ ensures Sorted_remove_original_ensures(A, x);
  @ assignable Sorted_remove_original_assignable(A, x); */
void original(int[] A, int x);

/*@ requires Sorted_remove_original_requires(A, x) && (\forall int i; 0 <= i < A.length; (\forall int j; i < j < A.length; A[i] <= A[j]));
  @ ensures (\forall int i; 0 <= i < A.length - 1; A[i] <= A[i + 1]);
  @ assignable A[*]; */
void main(int[] A, int x) {
    // CALLS void original(int[] A, int x)
    // CALLS void sort(int[] A)
    original(A, x);
    sort(A);
}
}