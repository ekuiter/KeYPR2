class Gen {
/*@ model boolean Cons_insert_original_requires(int[] A, int x) { return A.length > 0; }
  @ model boolean Cons_insert_original_ensures(int[] A, int x, int[] res) { return (\exists int i; 0 <= i < res.length; res[i] == x) && (\forall int i; 0 <= i < A.length; (\exists int j; 0 <= j < res.length; res[j] == A[i])); }
  @ model \locset Cons_insert_original_assignable(int[] A, int x) { return \set_minus(\nothing, \everything); } */

/*@ model boolean Snoc_insert_original_requires(int[] A, int x) { return Cons_insert_original_requires(A, x); }
  @ model boolean Snoc_insert_original_ensures(int[] A, int x, int[] res) { return Cons_insert_original_ensures(A, x, res); }
  @ model \locset Snoc_insert_original_assignable(int[] A, int x) { return \set_minus(\nothing, \everything); } */
/*@ requires Snoc_insert_original_requires(A, x);
  @ ensures Snoc_insert_original_ensures(A, x, \result);
  @ assignable Snoc_insert_original_assignable(A, x); */
int[] original(int[] A, int x);

/*@ requires Snoc_insert_original_requires(A, x);
  @ ensures Snoc_insert_original_ensures(A, x, \result);
  @ assignable \nothing; */
int[] main(int[] A, int x) {
    int i = 0;
    int[] result = new int[A.length + 1];
    result[0] = x;
    /*@ loop_invariant result.length == A.length + 1 && result[0] == x && 0 <= i && i <= A.length &&
		  @   (\forall int j; 0 <= j < i; (\exists int k; 1 <= k && k <= i; result[k] == A[j]));
		  @ decreases A.length - i;
		  @ assignable result[*], i; */
    while (i < A.length) {
        result[i + 1] = A[i];
        i = i + 1;
    }
    return result;
}
}