class Gen {

/*@ requires A.length > 0;
  @ ensures \result == A[A.length - 1];
  @ assignable \nothing; */
public int main(int[] A) {
    return A[A.length - 1];
}
}