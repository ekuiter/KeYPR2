class Gen {
/*@ model boolean Snoc_insert_original_requires(int[] A, int x);
  @ model boolean Snoc_insert_original_ensures(int[] A, int x, int[] res);
  @ model \locset Snoc_insert_original_assignable(int[] A, int x); */
/*@ requires Snoc_insert_original_requires(A, x);
  @ ensures Snoc_insert_original_ensures(A, x, \result);
  @ assignable Snoc_insert_original_assignable(A, x); */
int[] original(int[] A, int x);

/*@ requires Snoc_insert_original_requires(A, x);
  @ ensures Snoc_insert_original_ensures(A, x, \result);
  @ assignable \nothing; */
int[] main(int[] A, int x) {
    int i = 0;
    int[] result = new int[A.length + 1];
    result[0] = x;
    /*@ loop_invariant result.length == A.length + 1 && result[0] == x && 0 <= i && i <= A.length &&
		  @   (\forall int j; 0 <= j < i; (\exists int k; 1 <= k && k <= i; result[k] == A[j]));
		  @ decreases A.length - i;
		  @ assignable result[*], i; */
    while (i < A.length) {
        result[i + 1] = A[i];
        i = i + 1;
    }
    return result;
}
}