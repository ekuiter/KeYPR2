class Gen {

/*@ requires true;
  @ ensures \result <==> (A.length == 0);
  @ assignable \nothing; */
public boolean main(int[] A) {
    return A.length == 0;
}
}