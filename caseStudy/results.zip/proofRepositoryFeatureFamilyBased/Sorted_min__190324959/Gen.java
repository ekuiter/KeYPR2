class Gen {

/*@ requires A.length > 0 && 0 <= start < A.length;
  @ ensures start <= \result && \result < A.length && (\forall int i; start <= i < A.length; A[\result] <= A[i]);
  @ assignable \nothing; */
int main(int[] A, int start) {
    int cnt = start, _result = start;
    /*@ loop_invariant 0 <= start < A.length && start <= cnt && cnt <= A.length && start <= _result && _result < A.length &&
		  @   start < A.length && (\forall int i; start <= i < cnt; A[_result] <= A[i]);
		  @ decreases A.length - cnt;
		  @ assignable cnt, _result; */
    while (cnt < A.length) {
        if (A[cnt] < A[_result])
            _result = cnt;
        cnt++;
    }
    return _result;
}
}