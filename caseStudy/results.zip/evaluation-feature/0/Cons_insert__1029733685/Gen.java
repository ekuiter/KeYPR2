class Gen {
/*@ model boolean Cons_insert_original_requires(int[] A, int x);
  @ model boolean Cons_insert_original_ensures(int[] A, int x, int[] res);
  @ model \locset Cons_insert_original_assignable(int[] A, int x); */
/*@ requires Cons_insert_original_requires(A, x);
  @ ensures Cons_insert_original_ensures(A, x, \result);
  @ assignable Cons_insert_original_assignable(A, x); */
int[] original(int[] A, int x);

/*@ requires Cons_insert_original_requires(A, x);
  @ ensures Cons_insert_original_ensures(A, x, \result);
  @ assignable \nothing; */
int[] main(int[] A, int x) {
    return original(A, x);
}
}