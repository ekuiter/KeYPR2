class Gen {

/*@ requires A.length > 0;
  @ ensures \result <==> (\exists int i; 0 <= i < A.length; A[i] == x);
  @ assignable \nothing; */
boolean main(int[] A, int x) {
    int i = A.length - 1;
    /*@ loop_invariant -1 <= i < A.length && !(\exists int j; i + 1 <= j < A.length; A[j] == x);
		  @ decreases i + 1;
		  @ assignable i; */
    while (i >= 0 && A[i] != x) i--;
    return i != -1;
}
}