class Gen {
/*@ model boolean Sorted_search_original_requires(int[] A, int x);
  @ model boolean Sorted_search_original_ensures(int[] A, int x, boolean res);
  @ model \locset Sorted_search_original_assignable(int[] A, int x); */
/*@ requires Sorted_search_original_requires(A, x);
  @ ensures Sorted_search_original_ensures(A, x, \result);
  @ assignable Sorted_search_original_assignable(A, x); */
boolean original(int[] A, int x);

/*@ requires Sorted_search_original_requires(A, x) && (\forall int i; 0 <= i < A.length; (\forall int j; i < j < A.length; A[i] <= A[j]));
  @ ensures Sorted_search_original_ensures(A, x, \result);
  @ assignable \nothing; */
boolean main(int[] A, int x) {
    int l = 0, oldL, h = A.length;
    /*@ loop_invariant (\forall int i; 0 <= i < A.length; (\forall int j; i < j < A.length; A[i] <= A[j])) &&
		  @   ((\exists int i; 0 <= i < A.length; A[i] == x) ==> (\exists int i; l <= i < h; A[i] == x)) &&
		  @   0 <= h && h <= A.length && 0 <= l && l <= A.length;
		  @ decreases h - l;
		  @ assignable oldL, l, h; */
    while (h > l + 1) {
        if (x < A[(l + h) / 2])
            h = (l + h) / 2;
        else if (x > A[(l + h) / 2])
            l = (l + h) / 2;
        else {
            oldL = l;
            l = (l + h) / 2;
            h = (oldL + h) / 2 + 1;
        }
    }
    return h >= l + 1 && A[l] == x;
}
}