class Gen {

/*@ requires A.length > 0;
  @ ensures (\exists int i; 0 <= i < \result.length; \result[i] == x) && (\forall int i; 0 <= i < A.length; (\exists int j; 0 <= j < \result.length; \result[j] == A[i]));
  @ assignable \nothing; */
int[] main(int[] A, int x) {
    int i = 0;
    int[] result = new int[A.length + 1];
    result[result.length - 1] = x;
    /*@ loop_invariant result.length == A.length + 1 && result[result.length - 1] == x && 0 <= i && i <= A.length &&
		  @   (\forall int j; 0 <= j < i; (\exists int k; 0 <= k < i; result[k] == A[j]));
		  @ decreases A.length - i;
		  @ assignable result[*], i; */
    while (i < A.length) {
        result[i] = A[i];
        i = i + 1;
    }
    return result;
}
}