class Gen {

/*@ requires A.length > 0;
  @ ensures (\forall int i; 0 <= i < A.length; A[i] != x || A[i] == -1);
  @ assignable A[*]; */
void main(int[] A, int x) {
    int i = 0;
    /*@ loop_invariant 0 <= i && i <= A.length && A.length > 0 && (\forall int j; 0 <= j < i; A[j] != x || A[j] == -1);
		  @ decreases A.length - i;
		  @ assignable A[*], i; */
    while (i < A.length) {
        if (A[i] == x)
            A[i] = -1;
        i = i + 1;
    }
}
}