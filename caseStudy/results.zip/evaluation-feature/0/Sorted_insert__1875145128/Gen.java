class Gen {
/*@ model boolean Sorted_insert_sort_requires(int[] A);
  @ model boolean Sorted_insert_sort_ensures(int[] A);
  @ model \locset Sorted_insert_sort_assignable(int[] A); */
/*@ requires Sorted_insert_sort_requires(A);
  @ ensures Sorted_insert_sort_ensures(A);
  @ assignable Sorted_insert_sort_assignable(A); */
void sort(int[] A);

/*@ model boolean Sorted_insert_original_requires(int[] A, int x);
  @ model boolean Sorted_insert_original_ensures(int[] A, int x, int[] res);
  @ model \locset Sorted_insert_original_assignable(int[] A, int x); */
/*@ requires Sorted_insert_original_requires(A, x);
  @ ensures Sorted_insert_original_ensures(A, x, \result);
  @ assignable Sorted_insert_original_assignable(A, x); */
int[] original(int[] A, int x);

/*@ requires Sorted_insert_original_requires(A, x) && (\forall int i; 0 <= i < A.length; (\forall int j; i < j < A.length; A[i] <= A[j]));
  @ ensures (\forall int i; 0 <= i < \result.length - 1; \result[i] <= \result[i + 1]);
  @ assignable \everything; */
int[] main(int[] A, int x) {
    // CALLS int[] original(int[] A, int x)
    // CALLS void sort(int[] A)
    int[] _result = original(A, x);
    sort(_result);
    return _result;
}
}