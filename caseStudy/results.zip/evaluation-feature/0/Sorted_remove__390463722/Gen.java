class Gen {
/*@ model boolean Sorted_remove_sort_requires(int[] A);
  @ model boolean Sorted_remove_sort_ensures(int[] A);
  @ model \locset Sorted_remove_sort_assignable(int[] A); */
/*@ requires Sorted_remove_sort_requires(A);
  @ ensures Sorted_remove_sort_ensures(A);
  @ assignable Sorted_remove_sort_assignable(A); */
void sort(int[] A);

/*@ model boolean Sorted_remove_original_requires(int[] A, int x);
  @ model boolean Sorted_remove_original_ensures(int[] A, int x);
  @ model \locset Sorted_remove_original_assignable(int[] A, int x); */
/*@ requires Sorted_remove_original_requires(A, x);
  @ ensures Sorted_remove_original_ensures(A, x);
  @ assignable Sorted_remove_original_assignable(A, x); */
void original(int[] A, int x);

/*@ requires Sorted_remove_original_requires(A, x) && (\forall int i; 0 <= i < A.length; (\forall int j; i < j < A.length; A[i] <= A[j]));
  @ ensures (\forall int i; 0 <= i < A.length - 1; A[i] <= A[i + 1]);
  @ assignable A[*]; */
void main(int[] A, int x) {
    // CALLS void original(int[] A, int x)
    // CALLS void sort(int[] A)
    original(A, x);
    sort(A);
}
}