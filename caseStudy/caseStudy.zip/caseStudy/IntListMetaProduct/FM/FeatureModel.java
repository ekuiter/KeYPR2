package FM;

/**
 * Variability encoding of the feature model for KeY.
 * Auto-generated class.
 */
public class FeatureModel {

	public static boolean cons;
	public static boolean snoc;
	public static boolean base;
	public static boolean sorted;
	public static boolean stack;

	
}